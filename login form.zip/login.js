 
var x = document.getElementById("login");
var y = document.getElementById("register");
var z = document.getElementById("btn");
function register(){
    x.style.left = "-400px";
    y.style.left = "35px";
    z.style.left = "110px";


}
function login(){
    x.style.left = "30px";
    y.style.left = "500px";
    z.style.left = "0";


}
